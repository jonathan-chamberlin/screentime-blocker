// FocusContract Configuration — THIS FILE IS GITIGNORED
// Do not commit — contains Auth0 credentials
window.CONFIG = {
  AUTH0_DOMAIN: 'dev-vx6ajging71b4q1u.us.auth0.com',
  AUTH0_CLIENT_ID: 'IgH9708ZQn2TrctfrMqi3aoGoVXmSQ8M',
  AUTH0_AUDIENCE: '', // Set to your Auth0 API identifier once created (e.g. 'https://focuscontract-api')
  API_BASE_URL: 'http://localhost:3000',
};
