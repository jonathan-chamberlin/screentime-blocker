﻿// Generated at packaging time for Chrome Web Store safety.
// Set production values only if you intentionally ship leaderboard/auth.
window.CONFIG = {
  AUTH0_DOMAIN: '',
  AUTH0_CLIENT_ID: '',
  AUTH0_AUDIENCE: '',
  API_BASE_URL: '',
};
